import React from 'react';
import CustomerGrowthChart from './CustomerGrowthChart';

const GrowthChart = () => {
  // Implement chart rendering logic here
//   return <div id="customer-growth-chart" style={{ minHeight: '250px' }}></div>;
return(
    <CustomerGrowthChart/>
)
};

export default GrowthChart;
