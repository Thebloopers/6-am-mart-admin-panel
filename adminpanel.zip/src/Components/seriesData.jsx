// seriesData.js

const seriesData = {
    monthDataSeries1: {
      prices: [/* array of prices */],
      dates: [/* array of dates */]
    }
  };
  
  export default seriesData;
  