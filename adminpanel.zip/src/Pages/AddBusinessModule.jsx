import React from "react";
import withAuth from "../HOC/withAuth";

const AddBusinessModule = () => {
  return <div></div>;
};

export default withAuth(AddBusinessModule);
