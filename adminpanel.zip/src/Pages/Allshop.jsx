import React from "react";
import withAuth from "../HOC/withAuth";

function Allshop() {
  return <div>all shop</div>;
}

export default withAuth(Allshop);
