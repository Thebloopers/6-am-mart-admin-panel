import React from "react";
import withAuth from "../HOC/withAuth";

const FirebaseNotification = () => {
  return <div></div>;
};

export default withAuth(FirebaseNotification);
