import React from "react";
import withAuth from "../HOC/withAuth";

const Gallery = () => {
  return <div></div>;
};

export default withAuth(Gallery);
