import React from 'react'

const LoginUrlPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default LoginUrlPage
