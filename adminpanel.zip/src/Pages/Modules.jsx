import React from "react";
import withAuth from "../HOC/withAuth";

const Modules = () => {
  return <div></div>;
};

export default withAuth(Modules);
