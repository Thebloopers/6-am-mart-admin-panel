import React from "react";
import withAuth from "../HOC/withAuth";

const OfflinePaymentSetup = () => {
  return <div></div>;
};

export default withAuth(OfflinePaymentSetup);
