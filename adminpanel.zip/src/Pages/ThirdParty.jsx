import React from "react";
import withAuth from "../HOC/withAuth";

const ThirdParty = () => {
  return <div></div>;
};

export default withAuth(ThirdParty);
