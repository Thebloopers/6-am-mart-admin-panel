import React from "react";
import withAuth from "../HOC/withAuth";

function ZoneSetup() {
  return <div></div>;
}

export default withAuth(ZoneSetup);
